<?php

    // action hook for placing content above the 'subsidiaries' widget area
    thematic_abovesubasides();

    // action hook for creating the 'subsidiaries' widget area
    widget_area_subsidiaries();
    
    // action hook for placing content below the 'subsidiaries' widget area
    thematic_belowsubasides();
    
?>