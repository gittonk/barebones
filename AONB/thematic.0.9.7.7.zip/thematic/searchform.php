<?php
    
    // calls the search form
	thematic_search_form();
    
?>