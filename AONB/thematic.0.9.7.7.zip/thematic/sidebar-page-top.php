<?php

    // action hook for placing content above the 'page-top' widget area
    thematic_abovepagetop();

    // action hook for creating the 'page-top' widget area
    widget_area_page_top();

    // action hook for placing content below the 'page-top' widget area
    thematic_belowpagetop();
    
?>