<?php 

    // action hook for placing content above the 'index-insert' widget area
    thematic_aboveindexinsert();

    // action hook creating the 'index-insert' widget area
    widget_area_index_insert();

    // action hook for placing content below the 'index-insert' widget area
    thematic_belowindexinsert();
    
?>