<?php

    // action hook for placing content above the 'index-top' widget area
    thematic_aboveindextop();

    // action hook for creating the 'index-top' widget area
    widget_area_index_top();

    // action hook for placing content below the 'index-top' widget area
    thematic_belowindextop();
    
?>